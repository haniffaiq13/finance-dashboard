"use strict";exports.id=396,exports.ids=[396],exports.modules={6645:(e,t,a)=>{a.d(t,{Z:()=>o});var l=a(12125);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,l.Z)("LogIn",[["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}],["polyline",{points:"10 17 15 12 10 7",key:"1ail0h"}],["line",{x1:"15",x2:"3",y1:"12",y2:"12",key:"v6grx8"}]])},43618:(e,t,a)=>{a.d(t,{f:()=>n});var l=a(9885),o=a(43979),r=a(60080),s=l.forwardRef((e,t)=>(0,r.jsx)(o.WV.label,{...e,ref:t,onMouseDown:t=>{let a=t.target;a.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));s.displayName="Label";var n=s}};